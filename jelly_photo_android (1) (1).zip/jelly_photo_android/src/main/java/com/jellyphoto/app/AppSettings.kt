package com.jellyphoto.app

import android.content.Context

// Настройки приложения. Хранятся в SharedPreferences (как settings.cfg в Godot-версии).
class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var darkTheme = sp.getBoolean("dark_theme", false)
    var shakeStrength = sp.getFloat("shake_strength", 1f).coerceIn(0f, 3f)  // 0 = выкл, 1 = обычно, 3 = максимум
    var pinEdges = sp.getBoolean("pin_edges", true)                          // закреплять края выделения
    var grabStrength = sp.getFloat("grab_strength", 1f).coerceIn(0f, 3f)    // сила растяжки пальцем
    var loupeEnabled = sp.getBoolean("loupe_enabled", true)                  // лупа при рисовании
    var material = sp.getInt("jelly_material", 0).coerceIn(0, 3)             // 0 желе, 1 резина, 2 вода, 3 пудинг
    var vibration = sp.getBoolean("vibration", true)                         // вибрация при касании желе
    var blurUnder = sp.getBoolean("blur_under", true)                        // размытая заливка под желе

    fun save() {
        sp.edit()
            .putBoolean("dark_theme", darkTheme)
            .putFloat("shake_strength", shakeStrength)
            .putBoolean("pin_edges", pinEdges)
            .putFloat("grab_strength", grabStrength)
            .putBoolean("loupe_enabled", loupeEnabled)
            .putInt("jelly_material", material)
            .putBoolean("vibration", vibration)
            .putBoolean("blur_under", blurUnder)
            .apply()
    }

    fun mult(): FloatArray = MULT[material.coerceIn(0, MULT.size - 1)]

    companion object {
        val MATERIAL_NAMES = arrayOf("Желе", "Резина", "Вода", "Пудинг")
        // множители: [жёсткость возврата, связь между точками, затухание]
        val MULT = arrayOf(
            floatArrayOf(1.0f, 1.0f, 1.0f),
            floatArrayOf(3.0f, 1.5f, 1.6f),
            floatArrayOf(0.4f, 0.6f, 0.45f),
            floatArrayOf(0.7f, 1.2f, 3.0f)
        )
    }
}
