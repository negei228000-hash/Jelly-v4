package com.jellyphoto.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class JellyView(context: Context, private val cfg: AppSettings) : View(context) {

    // ---------- ТУТ КРУТИТЬ ФИЗИКУ ----------
    private val spring = 60f      // возврат в форму
    private val couple = 420f     // связь между соседними точками
    private val damp = 3.0f       // затухание (меньше = дольше трясётся)
    private val edgePin = 6f      // во сколько раз жёстче закреплён край
    // -----------------------------------------

    private class Jelly(
        val bmp: Bitmap, val fill: Bitmap,
        val left: Float, val top: Float, val cols: Int, val rows: Int
    ) {
        val n = (cols + 1) * (rows + 1)
        val rest = FloatArray(n * 2)
        val cur = FloatArray(n * 2)
        val disp = FloatArray(n * 2)
        val vel = FloatArray(n * 2)
        val edge = BooleanArray(n)

        init {
            val w = bmp.width.toFloat()
            val h = bmp.height.toFloat()
            for (j in 0..rows) {
                for (i in 0..cols) {
                    val idx = j * (cols + 1) + i
                    rest[idx * 2] = left + w * i / cols
                    rest[idx * 2 + 1] = top + h * j / rows
                    edge[idx] = i == 0 || j == 0 || i == cols || j == rows
                }
            }
        }
    }

    private var src: Bitmap? = null
    private var base: Bitmap? = null
    private var blurBase: Bitmap? = null
    private var mask: Bitmap? = null
    private var maskCanvas: Canvas? = null
    private var ox = 0f
    private var oy = 0f

    private val jellies = ArrayList<Jelly>()
    private val density = resources.displayMetrics.density

    var drawMode = false
        set(v) { field = v; invalidate() }
    var brush = 30f * density
    var onGrab: (() -> Unit)? = null

    private var minX = 0f
    private var minY = 0f
    private var maxX = 0f
    private var maxY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var touching = false
    private var lastTime = 0L

    private val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val overlayPaint = Paint().apply { alpha = 140 }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE32E33.toInt()
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE32E33.toInt()
        style = Paint.Style.FILL
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }
    private val loupeBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE32E33.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
    }
    private val loupePath = Path()

    private fun bgColor(): Int = if (cfg.darkTheme) 0xFF121214.toInt() else Color.WHITE

    fun hasPhoto() = base != null

    fun setPhoto(bmp: Bitmap) {
        src = bmp
        if (width > 0 && height > 0) rebuild()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (src != null && w > 0 && h > 0) rebuild()
    }

    private fun rebuild() {
        val s = src ?: return
        val k = min(width.toFloat() / s.width, height.toFloat() / s.height)
        val bw = max(1, (s.width * k).roundToInt())
        val bh = max(1, (s.height * k).roundToInt())
        val b = Bitmap.createScaledBitmap(s, bw, bh, true)
        base = b
        // размытая копия для заливки под вырезанным желе
        val small = Bitmap.createScaledBitmap(b, max(1, bw / 14), max(1, bh / 14), true)
        blurBase = Bitmap.createScaledBitmap(small, bw, bh, true)
        ox = (width - bw) / 2f
        oy = (height - bh) / 2f
        val m = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        mask = m
        maskCanvas = Canvas(m)
        jellies.clear()
        resetBounds()
        invalidate()
    }

    private fun resetBounds() {
        minX = Float.MAX_VALUE
        minY = Float.MAX_VALUE
        maxX = -Float.MAX_VALUE
        maxY = -Float.MAX_VALUE
    }

    fun reset() {
        jellies.clear()
        mask?.eraseColor(Color.TRANSPARENT)
        resetBounds()
        invalidate()
    }

    // Превращает обведённую область в желе. false = область не обведена.
    fun makeJelly(): Boolean {
        val b = base ?: return false
        val m = mask ?: return false
        if (minX > maxX) return false
        val l = floor(minX).toInt().coerceIn(0, b.width - 1)
        val t = floor(minY).toInt().coerceIn(0, b.height - 1)
        val r = ceil(maxX).toInt().coerceIn(l + 1, b.width)
        val bt = ceil(maxY).toInt().coerceIn(t + 1, b.height)
        val w = r - l
        val h = bt - t
        if (w < 8 || h < 8) return false

        val p = Paint()
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)

        val jb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(jb)
        c.drawBitmap(b, -l.toFloat(), -t.toFloat(), null)
        c.drawBitmap(m, -l.toFloat(), -t.toFloat(), p)

        val fb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val fc = Canvas(fb)
        fc.drawBitmap(blurBase ?: b, -l.toFloat(), -t.toFloat(), null)
        fc.drawBitmap(m, -l.toFloat(), -t.toFloat(), p)

        val cell = 26f * density
        val cols = (w / cell).toInt().coerceIn(3, 36)
        val rows = (h / cell).toInt().coerceIn(3, 36)
        jellies.add(Jelly(jb, fb, l.toFloat(), t.toFloat(), cols, rows))

        m.eraseColor(Color.TRANSPARENT)
        resetBounds()
        invalidate()
        return true
    }

    // ---------- физика ----------

    private fun step(j: Jelly, dt: Float): Boolean {
        val mm = cfg.mult()
        val pinned = cfg.pinEdges
        val sBase = spring * mm[0] * (if (pinned) 1f else 2.5f)
        val cpl = couple * mm[1]
        val dBase = damp * mm[2]
        val maxD = min(width, height) * 0.4f
        val stride = (j.cols + 1) * 2
        for (y in 0..j.rows) {
            for (x in 0..j.cols) {
                val idx = y * (j.cols + 1) + x
                val k = idx * 2
                var sx = 0f
                var sy = 0f
                var cnt = 0
                if (x > 0) { sx += j.disp[k - 2]; sy += j.disp[k - 1]; cnt++ }
                if (x < j.cols) { sx += j.disp[k + 2]; sy += j.disp[k + 3]; cnt++ }
                if (y > 0) { sx += j.disp[k - stride]; sy += j.disp[k - stride + 1]; cnt++ }
                if (y < j.rows) { sx += j.disp[k + stride]; sy += j.disp[k + stride + 1]; cnt++ }
                val pin = pinned && j.edge[idx]
                val sp = if (pin) sBase * edgePin else sBase
                val dp = if (pin) dBase * 4f else dBase
                val ax = -sp * j.disp[k] + cpl * (sx / cnt - j.disp[k]) - dp * j.vel[k]
                val ay = -sp * j.disp[k + 1] + cpl * (sy / cnt - j.disp[k + 1]) - dp * j.vel[k + 1]
                j.vel[k] += ax * dt
                j.vel[k + 1] += ay * dt
            }
        }
        var maxV = 0f
        var maxDisp = 0f
        for (k in 0 until j.n * 2) {
            j.vel[k] = j.vel[k].coerceIn(-1800f, 1800f)
            j.disp[k] = (j.disp[k] + j.vel[k] * dt).coerceIn(-maxD, maxD)
            maxV = max(maxV, abs(j.vel[k]))
            maxDisp = max(maxDisp, abs(j.disp[k]))
        }
        return maxV < 2f && maxDisp < 0.5f
    }

    private fun poke(x: Float, y: Float, ivx: Float, ivy: Float, radius: Float) {
        val r2 = radius * radius
        for (j in jellies) {
            for (idx in 0 until j.n) {
                val k = idx * 2
                val dx = j.rest[k] - x
                val dy = j.rest[k + 1] - y
                val dd = dx * dx + dy * dy
                if (dd < r2 * 4f) {
                    val f = exp(-dd / r2)
                    j.vel[k] += ivx * f
                    j.vel[k + 1] += ivy * f
                }
            }
        }
    }

    private fun hitsJelly(x: Float, y: Float): Boolean {
        for (j in jellies) {
            if (x >= j.left && x <= j.left + j.bmp.width && y >= j.top && y <= j.top + j.bmp.height) return true
        }
        return false
    }

    // Тряска телефона.
    fun shake(ix: Float, iy: Float) {
        val g = cfg.shakeStrength
        if (jellies.isEmpty() || g <= 0f) return
        for (j in jellies) {
            for (idx in 0 until j.n) {
                j.vel[idx * 2] += ix * g
                j.vel[idx * 2 + 1] += iy * g
            }
        }
        invalidate()
    }

    // ---------- рисование ----------

    private fun drawScene(canvas: Canvas, overlay: Boolean) {
        val b = base ?: return
        canvas.drawBitmap(b, 0f, 0f, photoPaint)
        if (cfg.blurUnder) {
            for (j in jellies) canvas.drawBitmap(j.fill, j.left, j.top, photoPaint)
        }
        for (j in jellies) {
            for (k in 0 until j.n * 2) j.cur[k] = j.rest[k] + j.disp[k]
            canvas.drawBitmapMesh(j.bmp, j.cols, j.rows, j.cur, 0, null, 0, photoPaint)
        }
        val m = mask
        if (overlay && m != null) canvas.drawBitmap(m, 0f, 0f, overlayPaint)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(bgColor())
        if (base == null) {
            hintPaint.color = if (cfg.darkTheme) 0xFF9A9AA0.toInt() else 0xFF99999F.toInt()
            hintPaint.textSize = 18f * density
            canvas.drawText("Нажми «Экспорт фото»", width / 2f, height / 2f - 4f * density, hintPaint)
            canvas.drawText("и выбери картинку", width / 2f, height / 2f + 24f * density, hintPaint)
            return
        }

        val now = System.nanoTime()
        val dt = min((now - lastTime) / 1.0e9f, 0.033f)
        lastTime = now
        var calm = true
        for (j in jellies) {
            if (!step(j, dt)) calm = false
        }

        canvas.save()
        canvas.translate(ox, oy)
        drawScene(canvas, true)
        canvas.restore()

        if (cfg.loupeEnabled && drawMode && touching) drawLoupe(canvas)

        if (!calm || touching) postInvalidateOnAnimation()
    }

    // Окошко-лупа: увеличенное место под пальцем, пока рисуешь.
    private fun drawLoupe(canvas: Canvas) {
        val size = 130f * density
        val margin = 12f * density
        val rad = 16f * density
        val fx = lastX + ox
        val fy = lastY + oy
        var left = width - size - margin
        val top = margin
        if (fx > left - size * 0.5f && fy < top + size * 1.5f) left = margin
        loupePath.reset()
        loupePath.addRoundRect(left, top, left + size, top + size, rad, rad, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(loupePath)
        canvas.drawColor(bgColor())
        canvas.translate(left + size / 2f, top + size / 2f)
        canvas.scale(2.5f, 2.5f)
        canvas.translate(-fx, -fy)
        canvas.translate(ox, oy)
        drawScene(canvas, true)
        canvas.restore()
        canvas.drawRoundRect(left, top, left + size, top + size, rad, rad, loupeBorder)
    }

    // Снимок для обоев: то, что на экране, растянутое на весь экран с обрезкой.
    fun snapshot(w: Int, h: Int): Bitmap? {
        val b = base ?: return null
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(bgColor())
        val s = max(w.toFloat() / b.width, h.toFloat() / b.height)
        c.translate((w - b.width * s) / 2f, (h - b.height * s) / 2f)
        c.scale(s, s)
        drawScene(c, false)
        return out
    }

    // ---------- касания ----------

    private fun stamp(x: Float, y: Float) {
        val c = maskCanvas ?: return
        c.drawCircle(x, y, brush / 2f, dotPaint)
        extend(x, y)
    }

    private fun paintLine(x1: Float, y1: Float, x2: Float, y2: Float) {
        val c = maskCanvas ?: return
        strokePaint.strokeWidth = brush
        c.drawLine(x1, y1, x2, y2, strokePaint)
        extend(x2, y2)
    }

    private fun extend(x: Float, y: Float) {
        val r = brush / 2f + 2f
        minX = min(minX, x - r)
        minY = min(minY, y - r)
        maxX = max(maxX, x + r)
        maxY = max(maxY, y + r)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (base == null) return false
        val x = e.x - ox
        val y = e.y - oy
        val rad = min(width, height) * 0.2f
        val g = cfg.grabStrength
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                lastX = x
                lastY = y
                if (drawMode) {
                    stamp(x, y)
                } else {
                    poke(x, y, 0f, 300f * g, rad)
                    if (hitsJelly(x, y)) onGrab?.invoke()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (drawMode) paintLine(lastX, lastY, x, y)
                else poke(x, y, (x - lastX) * 25f * g, (y - lastY) * 25f * g, rad * 0.9f)
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        invalidate()
        return true
    }
}
